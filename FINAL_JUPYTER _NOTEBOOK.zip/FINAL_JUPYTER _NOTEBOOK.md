```python
#import pandas and call it pd from this moment onwards in this notebook
#turn the excel_trans into a Pandas dataframe
import pandas as pd
df = pd.read_csv('excel_trans.csv', header=0, names = ['Age', 'Occupation', 'Country', 'CoD'])

df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Occupation</th>
      <th>Country</th>
      <th>CoD</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>36</td>
      <td>not reported</td>
      <td>Pakistan</td>
      <td>not reported</td>
    </tr>
    <tr>
      <th>1</th>
      <td>not reported</td>
      <td>not reported</td>
      <td>Myanmar</td>
      <td>shot</td>
    </tr>
    <tr>
      <th>2</th>
      <td>not reported</td>
      <td>sex worker</td>
      <td>Brazil</td>
      <td>beaten</td>
    </tr>
    <tr>
      <th>3</th>
      <td>not reported</td>
      <td>hair dresser</td>
      <td>Colombia</td>
      <td>shot</td>
    </tr>
    <tr>
      <th>4</th>
      <td>13</td>
      <td>not reported</td>
      <td>Brazil</td>
      <td>not reported</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>275</th>
      <td>32</td>
      <td>not reported</td>
      <td>Honduras</td>
      <td>stabbed</td>
    </tr>
    <tr>
      <th>276</th>
      <td>not reported</td>
      <td>not reported</td>
      <td>Mexico</td>
      <td>not reported</td>
    </tr>
    <tr>
      <th>277</th>
      <td>48</td>
      <td>not reported</td>
      <td>Philippines</td>
      <td>stabbed</td>
    </tr>
    <tr>
      <th>278</th>
      <td>not reported</td>
      <td>seller/merchant</td>
      <td>Mexico</td>
      <td>not reported</td>
    </tr>
    <tr>
      <th>279</th>
      <td>21</td>
      <td>not reported</td>
      <td>USA</td>
      <td>shot</td>
    </tr>
  </tbody>
</table>
<p>280 rows × 4 columns</p>
</div>




```python
#check out your columns names
df.columns
```




    Index(['Age', 'Occupation', 'Country', 'CoD'], dtype='object')




```python
#Delete doubles rows
df.drop_duplicates(keep='first',inplace=True)
```


```python
df.columns
```




    Index(['Age', 'Occupation', 'Country', 'CoD'], dtype='object')




```python
#return object containing counts of unique values
df.Age.value_counts()
```




    not reported    44
    25              16
    24              12
    30              11
    28              10
    35              10
    26               9
    32               8
    23               8
    29               8
    27               8
    20               7
    36               6
    16               6
    22               6
    41               5
    17               4
    44               4
    19               4
    21               4
    40               4
    31               4
    39               4
    43               3
    49               3
    18               3
    34               3
    45               3
    42               3
    37               2
    38               2
    33               2
    60               2
    64               2
    50               2
    51               1
    52               1
    14               1
    47               1
    54               1
    13               1
    68               1
    53               1
    48               1
    Name: Age, dtype: int64




```python
df.Occupation.value_counts()
```




    not reported                    137
    sex worker                       57
    hair dresser                     21
    employee/clerk/civil servant      7
    artist                            6
    activist/movement leader          6
    seller/merchant                   3
    waitress/waiter/bartender         1
    fishing                           1
    other                             1
    makeup artist/ sex worker         1
    Name: Occupation, dtype: int64




```python
df.Country.value_counts()
```




    Brazil         71
    Mexico         38
    USA            33
    Colombia       16
    Philippines    14
    Argentina      11
    Pakistan        8
    India           7
    Brazil          4
    Honduras        4
    El Salvador     4
    Ecuador         3
    Turkey          3
    France          3
    Venezuela       3
    Peru            2
    Myanmar         2
    Chile           2
    Italy           2
    Guatemala       2
    usa             1
    Malawi          1
    Kazakhstan      1
    Bolivia         1
    Greece          1
    Puerto Rico     1
    Nicaragua       1
    Portugal        1
    Azerbaijan      1
    Name: Country, dtype: int64




```python
df.CoD.value_counts()
```




    shot                                  92
    stabbed                               53
    not reported                          50
    beaten                                 9
    strangled/hanged                       7
    run-over by car                        7
    decapitated                            5
    stoned                                 5
    burned                                 4
    tortured                               4
    asphyxiation/inhalation/suffocated     4
    stangled/hanged                        1
    Name: CoD, dtype: int64




```python
#print data frame
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Occupation</th>
      <th>Country</th>
      <th>CoD</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>36</td>
      <td>not reported</td>
      <td>Pakistan</td>
      <td>not reported</td>
    </tr>
    <tr>
      <th>1</th>
      <td>not reported</td>
      <td>not reported</td>
      <td>Myanmar</td>
      <td>shot</td>
    </tr>
    <tr>
      <th>2</th>
      <td>not reported</td>
      <td>sex worker</td>
      <td>Brazil</td>
      <td>beaten</td>
    </tr>
    <tr>
      <th>3</th>
      <td>not reported</td>
      <td>hair dresser</td>
      <td>Colombia</td>
      <td>shot</td>
    </tr>
    <tr>
      <th>4</th>
      <td>13</td>
      <td>not reported</td>
      <td>Brazil</td>
      <td>not reported</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>273</th>
      <td>25</td>
      <td>not reported</td>
      <td>Peru</td>
      <td>stabbed</td>
    </tr>
    <tr>
      <th>274</th>
      <td>16</td>
      <td>not reported</td>
      <td>Mexico</td>
      <td>shot</td>
    </tr>
    <tr>
      <th>275</th>
      <td>32</td>
      <td>not reported</td>
      <td>Honduras</td>
      <td>stabbed</td>
    </tr>
    <tr>
      <th>277</th>
      <td>48</td>
      <td>not reported</td>
      <td>Philippines</td>
      <td>stabbed</td>
    </tr>
    <tr>
      <th>278</th>
      <td>not reported</td>
      <td>seller/merchant</td>
      <td>Mexico</td>
      <td>not reported</td>
    </tr>
  </tbody>
</table>
<p>241 rows × 4 columns</p>
</div>




```python
#Matplotlib setups
import matplotlib.font_manager
from IPython.core.display import HTML

def make_html(fontname):
    return "<p>{font}: <span style='font-family:{font}; font-size: 24px;'>{font}</p>".format(font=fontname)

code = "\n".join([make_html(font) for font in sorted(set([f.name for f in matplotlib.font_manager.fontManager.ttflist]))])

HTML("<div style='column-count: 2;'>{}</div>".format(code))
```




<div style='column-count: 2;'><p>Agency FB: <span style='font-family:Agency FB; font-size: 24px;'>Agency FB</p>
<p>Algerian: <span style='font-family:Algerian; font-size: 24px;'>Algerian</p>
<p>Arial: <span style='font-family:Arial; font-size: 24px;'>Arial</p>
<p>Arial Rounded MT Bold: <span style='font-family:Arial Rounded MT Bold; font-size: 24px;'>Arial Rounded MT Bold</p>
<p>Arial Unicode MS: <span style='font-family:Arial Unicode MS; font-size: 24px;'>Arial Unicode MS</p>
<p>Bahnschrift: <span style='font-family:Bahnschrift; font-size: 24px;'>Bahnschrift</p>
<p>Baskerville Old Face: <span style='font-family:Baskerville Old Face; font-size: 24px;'>Baskerville Old Face</p>
<p>Bauhaus 93: <span style='font-family:Bauhaus 93; font-size: 24px;'>Bauhaus 93</p>
<p>Bell MT: <span style='font-family:Bell MT; font-size: 24px;'>Bell MT</p>
<p>Berlin Sans FB: <span style='font-family:Berlin Sans FB; font-size: 24px;'>Berlin Sans FB</p>
<p>Berlin Sans FB Demi: <span style='font-family:Berlin Sans FB Demi; font-size: 24px;'>Berlin Sans FB Demi</p>
<p>Bernard MT Condensed: <span style='font-family:Bernard MT Condensed; font-size: 24px;'>Bernard MT Condensed</p>
<p>Blackadder ITC: <span style='font-family:Blackadder ITC; font-size: 24px;'>Blackadder ITC</p>
<p>Bodoni MT: <span style='font-family:Bodoni MT; font-size: 24px;'>Bodoni MT</p>
<p>Book Antiqua: <span style='font-family:Book Antiqua; font-size: 24px;'>Book Antiqua</p>
<p>Bookman Old Style: <span style='font-family:Bookman Old Style; font-size: 24px;'>Bookman Old Style</p>
<p>Bookshelf Symbol 7: <span style='font-family:Bookshelf Symbol 7; font-size: 24px;'>Bookshelf Symbol 7</p>
<p>Bradley Hand ITC: <span style='font-family:Bradley Hand ITC; font-size: 24px;'>Bradley Hand ITC</p>
<p>Britannic Bold: <span style='font-family:Britannic Bold; font-size: 24px;'>Britannic Bold</p>
<p>Broadway: <span style='font-family:Broadway; font-size: 24px;'>Broadway</p>
<p>Brush Script MT: <span style='font-family:Brush Script MT; font-size: 24px;'>Brush Script MT</p>
<p>Calibri: <span style='font-family:Calibri; font-size: 24px;'>Calibri</p>
<p>Californian FB: <span style='font-family:Californian FB; font-size: 24px;'>Californian FB</p>
<p>Calisto MT: <span style='font-family:Calisto MT; font-size: 24px;'>Calisto MT</p>
<p>Cambria: <span style='font-family:Cambria; font-size: 24px;'>Cambria</p>
<p>Candara: <span style='font-family:Candara; font-size: 24px;'>Candara</p>
<p>Cascadia Code: <span style='font-family:Cascadia Code; font-size: 24px;'>Cascadia Code</p>
<p>Cascadia Mono: <span style='font-family:Cascadia Mono; font-size: 24px;'>Cascadia Mono</p>
<p>Castellar: <span style='font-family:Castellar; font-size: 24px;'>Castellar</p>
<p>Centaur: <span style='font-family:Centaur; font-size: 24px;'>Centaur</p>
<p>Century: <span style='font-family:Century; font-size: 24px;'>Century</p>
<p>Century Gothic: <span style='font-family:Century Gothic; font-size: 24px;'>Century Gothic</p>
<p>Century Schoolbook: <span style='font-family:Century Schoolbook; font-size: 24px;'>Century Schoolbook</p>
<p>Chiller: <span style='font-family:Chiller; font-size: 24px;'>Chiller</p>
<p>Colonna MT: <span style='font-family:Colonna MT; font-size: 24px;'>Colonna MT</p>
<p>Comic Sans MS: <span style='font-family:Comic Sans MS; font-size: 24px;'>Comic Sans MS</p>
<p>Consolas: <span style='font-family:Consolas; font-size: 24px;'>Consolas</p>
<p>Constantia: <span style='font-family:Constantia; font-size: 24px;'>Constantia</p>
<p>Cooper Black: <span style='font-family:Cooper Black; font-size: 24px;'>Cooper Black</p>
<p>Copperplate Gothic Bold: <span style='font-family:Copperplate Gothic Bold; font-size: 24px;'>Copperplate Gothic Bold</p>
<p>Copperplate Gothic Light: <span style='font-family:Copperplate Gothic Light; font-size: 24px;'>Copperplate Gothic Light</p>
<p>Corbel: <span style='font-family:Corbel; font-size: 24px;'>Corbel</p>
<p>Courier New: <span style='font-family:Courier New; font-size: 24px;'>Courier New</p>
<p>Curlz MT: <span style='font-family:Curlz MT; font-size: 24px;'>Curlz MT</p>
<p>DejaVu Sans: <span style='font-family:DejaVu Sans; font-size: 24px;'>DejaVu Sans</p>
<p>DejaVu Sans Display: <span style='font-family:DejaVu Sans Display; font-size: 24px;'>DejaVu Sans Display</p>
<p>DejaVu Sans Mono: <span style='font-family:DejaVu Sans Mono; font-size: 24px;'>DejaVu Sans Mono</p>
<p>DejaVu Serif: <span style='font-family:DejaVu Serif; font-size: 24px;'>DejaVu Serif</p>
<p>DejaVu Serif Display: <span style='font-family:DejaVu Serif Display; font-size: 24px;'>DejaVu Serif Display</p>
<p>Ebrima: <span style='font-family:Ebrima; font-size: 24px;'>Ebrima</p>
<p>Edwardian Script ITC: <span style='font-family:Edwardian Script ITC; font-size: 24px;'>Edwardian Script ITC</p>
<p>Elephant: <span style='font-family:Elephant; font-size: 24px;'>Elephant</p>
<p>Engravers MT: <span style='font-family:Engravers MT; font-size: 24px;'>Engravers MT</p>
<p>Eras Bold ITC: <span style='font-family:Eras Bold ITC; font-size: 24px;'>Eras Bold ITC</p>
<p>Eras Demi ITC: <span style='font-family:Eras Demi ITC; font-size: 24px;'>Eras Demi ITC</p>
<p>Eras Light ITC: <span style='font-family:Eras Light ITC; font-size: 24px;'>Eras Light ITC</p>
<p>Eras Medium ITC: <span style='font-family:Eras Medium ITC; font-size: 24px;'>Eras Medium ITC</p>
<p>Felix Titling: <span style='font-family:Felix Titling; font-size: 24px;'>Felix Titling</p>
<p>Footlight MT Light: <span style='font-family:Footlight MT Light; font-size: 24px;'>Footlight MT Light</p>
<p>Forte: <span style='font-family:Forte; font-size: 24px;'>Forte</p>
<p>Franklin Gothic Book: <span style='font-family:Franklin Gothic Book; font-size: 24px;'>Franklin Gothic Book</p>
<p>Franklin Gothic Demi: <span style='font-family:Franklin Gothic Demi; font-size: 24px;'>Franklin Gothic Demi</p>
<p>Franklin Gothic Demi Cond: <span style='font-family:Franklin Gothic Demi Cond; font-size: 24px;'>Franklin Gothic Demi Cond</p>
<p>Franklin Gothic Heavy: <span style='font-family:Franklin Gothic Heavy; font-size: 24px;'>Franklin Gothic Heavy</p>
<p>Franklin Gothic Medium: <span style='font-family:Franklin Gothic Medium; font-size: 24px;'>Franklin Gothic Medium</p>
<p>Franklin Gothic Medium Cond: <span style='font-family:Franklin Gothic Medium Cond; font-size: 24px;'>Franklin Gothic Medium Cond</p>
<p>Freestyle Script: <span style='font-family:Freestyle Script; font-size: 24px;'>Freestyle Script</p>
<p>French Script MT: <span style='font-family:French Script MT; font-size: 24px;'>French Script MT</p>
<p>Gabriola: <span style='font-family:Gabriola; font-size: 24px;'>Gabriola</p>
<p>Gadugi: <span style='font-family:Gadugi; font-size: 24px;'>Gadugi</p>
<p>Garamond: <span style='font-family:Garamond; font-size: 24px;'>Garamond</p>
<p>Georgia: <span style='font-family:Georgia; font-size: 24px;'>Georgia</p>
<p>Gigi: <span style='font-family:Gigi; font-size: 24px;'>Gigi</p>
<p>Gill Sans MT: <span style='font-family:Gill Sans MT; font-size: 24px;'>Gill Sans MT</p>
<p>Gill Sans MT Condensed: <span style='font-family:Gill Sans MT Condensed; font-size: 24px;'>Gill Sans MT Condensed</p>
<p>Gill Sans MT Ext Condensed Bold: <span style='font-family:Gill Sans MT Ext Condensed Bold; font-size: 24px;'>Gill Sans MT Ext Condensed Bold</p>
<p>Gill Sans Ultra Bold: <span style='font-family:Gill Sans Ultra Bold; font-size: 24px;'>Gill Sans Ultra Bold</p>
<p>Gill Sans Ultra Bold Condensed: <span style='font-family:Gill Sans Ultra Bold Condensed; font-size: 24px;'>Gill Sans Ultra Bold Condensed</p>
<p>Gloucester MT Extra Condensed: <span style='font-family:Gloucester MT Extra Condensed; font-size: 24px;'>Gloucester MT Extra Condensed</p>
<p>Goudy Old Style: <span style='font-family:Goudy Old Style; font-size: 24px;'>Goudy Old Style</p>
<p>Goudy Stout: <span style='font-family:Goudy Stout; font-size: 24px;'>Goudy Stout</p>
<p>Haettenschweiler: <span style='font-family:Haettenschweiler; font-size: 24px;'>Haettenschweiler</p>
<p>Harlow Solid Italic: <span style='font-family:Harlow Solid Italic; font-size: 24px;'>Harlow Solid Italic</p>
<p>Harrington: <span style='font-family:Harrington; font-size: 24px;'>Harrington</p>
<p>High Tower Text: <span style='font-family:High Tower Text; font-size: 24px;'>High Tower Text</p>
<p>HoloLens MDL2 Assets: <span style='font-family:HoloLens MDL2 Assets; font-size: 24px;'>HoloLens MDL2 Assets</p>
<p>Impact: <span style='font-family:Impact; font-size: 24px;'>Impact</p>
<p>Imprint MT Shadow: <span style='font-family:Imprint MT Shadow; font-size: 24px;'>Imprint MT Shadow</p>
<p>Informal Roman: <span style='font-family:Informal Roman; font-size: 24px;'>Informal Roman</p>
<p>Ink Free: <span style='font-family:Ink Free; font-size: 24px;'>Ink Free</p>
<p>Javanese Text: <span style='font-family:Javanese Text; font-size: 24px;'>Javanese Text</p>
<p>Jokerman: <span style='font-family:Jokerman; font-size: 24px;'>Jokerman</p>
<p>Juice ITC: <span style='font-family:Juice ITC; font-size: 24px;'>Juice ITC</p>
<p>Kristen ITC: <span style='font-family:Kristen ITC; font-size: 24px;'>Kristen ITC</p>
<p>Kunstler Script: <span style='font-family:Kunstler Script; font-size: 24px;'>Kunstler Script</p>
<p>Leelawadee UI: <span style='font-family:Leelawadee UI; font-size: 24px;'>Leelawadee UI</p>
<p>Lucida Bright: <span style='font-family:Lucida Bright; font-size: 24px;'>Lucida Bright</p>
<p>Lucida Calligraphy: <span style='font-family:Lucida Calligraphy; font-size: 24px;'>Lucida Calligraphy</p>
<p>Lucida Console: <span style='font-family:Lucida Console; font-size: 24px;'>Lucida Console</p>
<p>Lucida Fax: <span style='font-family:Lucida Fax; font-size: 24px;'>Lucida Fax</p>
<p>Lucida Handwriting: <span style='font-family:Lucida Handwriting; font-size: 24px;'>Lucida Handwriting</p>
<p>Lucida Sans: <span style='font-family:Lucida Sans; font-size: 24px;'>Lucida Sans</p>
<p>Lucida Sans Typewriter: <span style='font-family:Lucida Sans Typewriter; font-size: 24px;'>Lucida Sans Typewriter</p>
<p>Lucida Sans Unicode: <span style='font-family:Lucida Sans Unicode; font-size: 24px;'>Lucida Sans Unicode</p>
<p>MS Gothic: <span style='font-family:MS Gothic; font-size: 24px;'>MS Gothic</p>
<p>MS Mincho: <span style='font-family:MS Mincho; font-size: 24px;'>MS Mincho</p>
<p>MS Outlook: <span style='font-family:MS Outlook; font-size: 24px;'>MS Outlook</p>
<p>MS Reference Sans Serif: <span style='font-family:MS Reference Sans Serif; font-size: 24px;'>MS Reference Sans Serif</p>
<p>MS Reference Specialty: <span style='font-family:MS Reference Specialty; font-size: 24px;'>MS Reference Specialty</p>
<p>MV Boli: <span style='font-family:MV Boli; font-size: 24px;'>MV Boli</p>
<p>Magneto: <span style='font-family:Magneto; font-size: 24px;'>Magneto</p>
<p>Maiandra GD: <span style='font-family:Maiandra GD; font-size: 24px;'>Maiandra GD</p>
<p>Malgun Gothic: <span style='font-family:Malgun Gothic; font-size: 24px;'>Malgun Gothic</p>
<p>Matura MT Script Capitals: <span style='font-family:Matura MT Script Capitals; font-size: 24px;'>Matura MT Script Capitals</p>
<p>Microsoft Himalaya: <span style='font-family:Microsoft Himalaya; font-size: 24px;'>Microsoft Himalaya</p>
<p>Microsoft JhengHei: <span style='font-family:Microsoft JhengHei; font-size: 24px;'>Microsoft JhengHei</p>
<p>Microsoft New Tai Lue: <span style='font-family:Microsoft New Tai Lue; font-size: 24px;'>Microsoft New Tai Lue</p>
<p>Microsoft PhagsPa: <span style='font-family:Microsoft PhagsPa; font-size: 24px;'>Microsoft PhagsPa</p>
<p>Microsoft Sans Serif: <span style='font-family:Microsoft Sans Serif; font-size: 24px;'>Microsoft Sans Serif</p>
<p>Microsoft Tai Le: <span style='font-family:Microsoft Tai Le; font-size: 24px;'>Microsoft Tai Le</p>
<p>Microsoft YaHei: <span style='font-family:Microsoft YaHei; font-size: 24px;'>Microsoft YaHei</p>
<p>Microsoft Yi Baiti: <span style='font-family:Microsoft Yi Baiti; font-size: 24px;'>Microsoft Yi Baiti</p>
<p>MingLiU-ExtB: <span style='font-family:MingLiU-ExtB; font-size: 24px;'>MingLiU-ExtB</p>
<p>Mistral: <span style='font-family:Mistral; font-size: 24px;'>Mistral</p>
<p>Modern No. 20: <span style='font-family:Modern No. 20; font-size: 24px;'>Modern No. 20</p>
<p>Mongolian Baiti: <span style='font-family:Mongolian Baiti; font-size: 24px;'>Mongolian Baiti</p>
<p>Monotype Corsiva: <span style='font-family:Monotype Corsiva; font-size: 24px;'>Monotype Corsiva</p>
<p>Myanmar Text: <span style='font-family:Myanmar Text; font-size: 24px;'>Myanmar Text</p>
<p>Niagara Engraved: <span style='font-family:Niagara Engraved; font-size: 24px;'>Niagara Engraved</p>
<p>Niagara Solid: <span style='font-family:Niagara Solid; font-size: 24px;'>Niagara Solid</p>
<p>Nirmala UI: <span style='font-family:Nirmala UI; font-size: 24px;'>Nirmala UI</p>
<p>OCR A Extended: <span style='font-family:OCR A Extended; font-size: 24px;'>OCR A Extended</p>
<p>Old English Text MT: <span style='font-family:Old English Text MT; font-size: 24px;'>Old English Text MT</p>
<p>Onyx: <span style='font-family:Onyx; font-size: 24px;'>Onyx</p>
<p>Palace Script MT: <span style='font-family:Palace Script MT; font-size: 24px;'>Palace Script MT</p>
<p>Palatino Linotype: <span style='font-family:Palatino Linotype; font-size: 24px;'>Palatino Linotype</p>
<p>Papyrus: <span style='font-family:Papyrus; font-size: 24px;'>Papyrus</p>
<p>Parchment: <span style='font-family:Parchment; font-size: 24px;'>Parchment</p>
<p>Perpetua: <span style='font-family:Perpetua; font-size: 24px;'>Perpetua</p>
<p>Perpetua Titling MT: <span style='font-family:Perpetua Titling MT; font-size: 24px;'>Perpetua Titling MT</p>
<p>Playbill: <span style='font-family:Playbill; font-size: 24px;'>Playbill</p>
<p>Poor Richard: <span style='font-family:Poor Richard; font-size: 24px;'>Poor Richard</p>
<p>Pristina: <span style='font-family:Pristina; font-size: 24px;'>Pristina</p>
<p>Rage Italic: <span style='font-family:Rage Italic; font-size: 24px;'>Rage Italic</p>
<p>Ravie: <span style='font-family:Ravie; font-size: 24px;'>Ravie</p>
<p>Rockwell: <span style='font-family:Rockwell; font-size: 24px;'>Rockwell</p>
<p>Rockwell Condensed: <span style='font-family:Rockwell Condensed; font-size: 24px;'>Rockwell Condensed</p>
<p>Rockwell Extra Bold: <span style='font-family:Rockwell Extra Bold; font-size: 24px;'>Rockwell Extra Bold</p>
<p>STIXGeneral: <span style='font-family:STIXGeneral; font-size: 24px;'>STIXGeneral</p>
<p>STIXNonUnicode: <span style='font-family:STIXNonUnicode; font-size: 24px;'>STIXNonUnicode</p>
<p>STIXSizeFiveSym: <span style='font-family:STIXSizeFiveSym; font-size: 24px;'>STIXSizeFiveSym</p>
<p>STIXSizeFourSym: <span style='font-family:STIXSizeFourSym; font-size: 24px;'>STIXSizeFourSym</p>
<p>STIXSizeOneSym: <span style='font-family:STIXSizeOneSym; font-size: 24px;'>STIXSizeOneSym</p>
<p>STIXSizeThreeSym: <span style='font-family:STIXSizeThreeSym; font-size: 24px;'>STIXSizeThreeSym</p>
<p>STIXSizeTwoSym: <span style='font-family:STIXSizeTwoSym; font-size: 24px;'>STIXSizeTwoSym</p>
<p>Script MT Bold: <span style='font-family:Script MT Bold; font-size: 24px;'>Script MT Bold</p>
<p>Segoe MDL2 Assets: <span style='font-family:Segoe MDL2 Assets; font-size: 24px;'>Segoe MDL2 Assets</p>
<p>Segoe Print: <span style='font-family:Segoe Print; font-size: 24px;'>Segoe Print</p>
<p>Segoe Script: <span style='font-family:Segoe Script; font-size: 24px;'>Segoe Script</p>
<p>Segoe UI: <span style='font-family:Segoe UI; font-size: 24px;'>Segoe UI</p>
<p>Segoe UI Emoji: <span style='font-family:Segoe UI Emoji; font-size: 24px;'>Segoe UI Emoji</p>
<p>Segoe UI Historic: <span style='font-family:Segoe UI Historic; font-size: 24px;'>Segoe UI Historic</p>
<p>Segoe UI Symbol: <span style='font-family:Segoe UI Symbol; font-size: 24px;'>Segoe UI Symbol</p>
<p>Showcard Gothic: <span style='font-family:Showcard Gothic; font-size: 24px;'>Showcard Gothic</p>
<p>SimSun: <span style='font-family:SimSun; font-size: 24px;'>SimSun</p>
<p>SimSun-ExtB: <span style='font-family:SimSun-ExtB; font-size: 24px;'>SimSun-ExtB</p>
<p>Sitka Small: <span style='font-family:Sitka Small; font-size: 24px;'>Sitka Small</p>
<p>Snap ITC: <span style='font-family:Snap ITC; font-size: 24px;'>Snap ITC</p>
<p>Stencil: <span style='font-family:Stencil; font-size: 24px;'>Stencil</p>
<p>Sylfaen: <span style='font-family:Sylfaen; font-size: 24px;'>Sylfaen</p>
<p>Symbol: <span style='font-family:Symbol; font-size: 24px;'>Symbol</p>
<p>Tahoma: <span style='font-family:Tahoma; font-size: 24px;'>Tahoma</p>
<p>TeamViewer15: <span style='font-family:TeamViewer15; font-size: 24px;'>TeamViewer15</p>
<p>Tempus Sans ITC: <span style='font-family:Tempus Sans ITC; font-size: 24px;'>Tempus Sans ITC</p>
<p>Times New Roman: <span style='font-family:Times New Roman; font-size: 24px;'>Times New Roman</p>
<p>Trebuchet MS: <span style='font-family:Trebuchet MS; font-size: 24px;'>Trebuchet MS</p>
<p>Tw Cen MT: <span style='font-family:Tw Cen MT; font-size: 24px;'>Tw Cen MT</p>
<p>Tw Cen MT Condensed: <span style='font-family:Tw Cen MT Condensed; font-size: 24px;'>Tw Cen MT Condensed</p>
<p>Tw Cen MT Condensed Extra Bold: <span style='font-family:Tw Cen MT Condensed Extra Bold; font-size: 24px;'>Tw Cen MT Condensed Extra Bold</p>
<p>Verdana: <span style='font-family:Verdana; font-size: 24px;'>Verdana</p>
<p>Viner Hand ITC: <span style='font-family:Viner Hand ITC; font-size: 24px;'>Viner Hand ITC</p>
<p>Vivaldi: <span style='font-family:Vivaldi; font-size: 24px;'>Vivaldi</p>
<p>Vladimir Script: <span style='font-family:Vladimir Script; font-size: 24px;'>Vladimir Script</p>
<p>Webdings: <span style='font-family:Webdings; font-size: 24px;'>Webdings</p>
<p>Wide Latin: <span style='font-family:Wide Latin; font-size: 24px;'>Wide Latin</p>
<p>Wingdings: <span style='font-family:Wingdings; font-size: 24px;'>Wingdings</p>
<p>Wingdings 2: <span style='font-family:Wingdings 2; font-size: 24px;'>Wingdings 2</p>
<p>Wingdings 3: <span style='font-family:Wingdings 3; font-size: 24px;'>Wingdings 3</p>
<p>Yu Gothic: <span style='font-family:Yu Gothic; font-size: 24px;'>Yu Gothic</p>
<p>cmb10: <span style='font-family:cmb10; font-size: 24px;'>cmb10</p>
<p>cmex10: <span style='font-family:cmex10; font-size: 24px;'>cmex10</p>
<p>cmmi10: <span style='font-family:cmmi10; font-size: 24px;'>cmmi10</p>
<p>cmr10: <span style='font-family:cmr10; font-size: 24px;'>cmr10</p>
<p>cmss10: <span style='font-family:cmss10; font-size: 24px;'>cmss10</p>
<p>cmsy10: <span style='font-family:cmsy10; font-size: 24px;'>cmsy10</p>
<p>cmtt10: <span style='font-family:cmtt10; font-size: 24px;'>cmtt10</p></div>




```python
from pandas.core.arrays.numeric import np
```


```python
#taking all the 'ages' and put it in a df
onlyAges = df.Age.values
#cleaning 'not reported' from the df and put them in a new df
reportedAges = onlyAges[onlyAges != 'not reported']
```


```python
import matplotlib.pyplot as plt
import numpy as np

#The import numpy portion of the code brings the NumPy library into your current environment. ageCounts will make a double df to print uniqueAges. For moral reasoning'not reported' is not included.
uniqueAges, ageCounts = np.unique(reportedAges, return_counts=True)

highest  = np.amax(ageCounts)
colors = ["purple" if i == highest else "pink" for i in ageCounts]

pltAges = plt
pltAges.figure(figsize=(20,6)) 
pltAges.bar(uniqueAges, ageCounts, color=colors)
pltAges.xlabel('Age')
pltAges.ylabel('Frequency')
pltAges.title('Frequency of Ages') 
pltAges.show()
```


    
![png](output_12_0.png)
    



```python
df.to_csv('data.csv')
```


```python
#same as Frequency of Ages
onlyOccupation = df.Occupation.values 
reportedOccupation = onlyOccupation[onlyOccupation != 'not reported']
uniqueOccupation, occupationCounts = np.unique(reportedOccupation, return_counts=True) 

highest  = np.amax(occupationCounts)
colors = ["orange" if i == highest else "blue" for i in occupationCounts]

pltOccupation = plt
pltOccupation.figure(figsize=(20,8))
pltOccupation.bar(uniqueOccupation, occupationCounts, color=colors)
pltOccupation.xlabel('Occupation')
pltOccupation.ylabel('Frequency')
pltOccupation.title('Occupations') 
pltOccupation.show()
```


    
![png](output_14_0.png)
    



```python
onlyCountry = df.Country.values 
reportedCountry = onlyCountry[onlyCountry != 'not reported']
uniqueCountry, CountryCounts = np.unique(reportedCountry, return_counts=True) 

highest  = np.amax(CountryCounts)
colors = ["orange" if i == highest else "blue" for i in CountryCounts]

pltCountry = plt
pltCountry.figure(figsize=(30,6))
pltCountry.bar(uniqueCountry, CountryCounts, color=colors)
pltCountry.xlabel('Country')
pltCountry.ylabel('Frequency')
pltCountry.title('Frequency of murders per Country') 
pltCountry.show()
```


    
![png](output_15_0.png)
    



```python

```
